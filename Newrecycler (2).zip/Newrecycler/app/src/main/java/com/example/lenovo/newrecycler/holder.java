package com.example.pavan.recyclerview;

import android.media.Image;

public class holder {
    public String type;
    private String Title,Titlenew;
    int Image,Imagenew;

    //public holder() {
    //}

    public holder( int image,String   title,int imagenew,String titlenew) {

        Image=image;
        Title = title;
        Imagenew=imagenew;
        Titlenew=titlenew;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getTitlenew() {
        return Titlenew;
    }

    public void setTitlenew(String titlenew) {
        Titlenew = titlenew;
    }

    public int getImage() {
        return Image;
    }

    public void setImage(int image) {
        Image = image;
    }

    public int getImagenew() {
        return Imagenew;
    }

    public void setImagenew(int imagenew) {
        Imagenew = imagenew;
    }
}
