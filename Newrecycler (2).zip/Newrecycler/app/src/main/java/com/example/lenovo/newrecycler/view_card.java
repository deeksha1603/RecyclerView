package com.example.lenovo.newrecycler;



import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class view_card extends AppCompatActivity {
    ImageView img;
    TextView txt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_card);
        img=findViewById(R.id.imageView2);
        txt=findViewById(R.id.textView);


        Intent intent = getIntent();
        String Title = intent.getExtras().getString("Title");

        int image = intent.getExtras().getInt("Image") ;


        txt.setText(Title);

        img.setImageResource(image);
    }
}

